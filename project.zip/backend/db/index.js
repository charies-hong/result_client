'use strict';

const config = require('../config.js');
const mongoose = require('mongoose');

const dbConnection = config.DB_CONNECTION;
mongoose.set('useCreateIndex', true);

mongoose.connect(dbConnection, {
	useNewUrlParser: true,
	useUnifiedTopology: true,
});

const db = mongoose.connection;

db.on('error', () => {
	console.log('A database error has occurred.');
});

db.once('open', () => {
	console.log('Connected to database successfully.');
});

module.exports = mongoose;
