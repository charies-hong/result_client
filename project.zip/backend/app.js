'use strict';

const config = require('./config.js');
const express = require('express');
const session = require('cookie-session');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const hpp = require('hpp');
const csurf = require('csurf');
const rateLimit = require("express-rate-limit");
//const Provider = require('oidc-provider');

var indexRouter = require('./controllers/index');
var webauthnRouter = require('./controllers/webauthn');

const app = express();
app.use(express.json({}));

//const oidc = new Provider(`http://localhost:${config.PORT}`);

const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100 // Limit each IP to 100 requests per windowMs
});

app.use(helmet());
app.use(hpp());

app.use(
    session({
        name: 'session',
        secret: config.SESSION_SECRET,
        expires: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
    })
);

app.use(cookieParser());

//app.use(csurf());
app.use(limiter);

app.use('/', indexRouter);
app.use('/webauthn', webauthnRouter);
//app.use('/oidc', oidc.callback);

app.listen(config.PORT, config.HOST, () => {
    console.log(`NODE_ENV=${config.NODE_ENV}`);
    console.log(`App listening at http://${config.HOST}:${config.PORT}`);
});