const dotenv = require('dotenv').config();

module.exports = {
    NODE_ENV: process.env.NODE_ENV || 'development',
    HOST: process.env.HOST || '127.0.0.1',
    RP_ID: process.env.RP_ID || 'localhost',
    DB_CONNECTION: process.env.DB_CONNECTION || 'localhost',
    PORT: process.env.PORT || 3000,
    SESSION_SECRET: process.env.SESSION_SECRET || 'invalidSecretKey'
}