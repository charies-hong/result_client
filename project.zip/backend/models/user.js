const mongoose = require('../db');

const User = mongoose.model(
	'User',
	new mongoose.Schema({
		id: {
			type: String,
			unique: true,
		},
		name: {
			type: String,
			unique: false,
		},
		email: {
			type: String,
			unique: true,
		},
		authenticators: {
			type: Array,
		},
		registered: {
			type: Boolean,
			default: false,
		},
	})
);

module.exports = User;
