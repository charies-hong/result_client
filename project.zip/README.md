# CuteHorse

Main repository for GradProject which contains all of it's modules. This project really needs a real name.

#### TO-DO:
- UI/UX Design for Mobile App
- UI/UX Design for Web App
- OAuth Identity Provider API
- Password-less with WebAuthn
- Other normal web app and backend stuff

## Getting Started

You can get started by cloning the repository on your desktop. Each module is located within its on main folder from the root directory. 

### Prerequisites

This project requires NodeJS 14, Docker, and Expo CLI installed. After cloning this repository, the Expo CLI can be installed by running `npm install --global expo-cli` in your terminal.

### Usage
Each individual module can be run independently, or it can be run as a whole through Docker. In order to run the backend and frontend together using Docker, navigate to the root folder and run `docker-compose up --build` to start everything up. Ensure Docker is running on your computer before running the command. Once run, navigate to `localhost` to view the frontend. All API endpoints are accessible through the `/api/` path.

In addition, you can run each individual module on its own. Below the commands to run each individual module is defined.

You also need to run `npm install` in each module directory for the first time before running them.

```
// Backend - Replace dev with prod depending on development or production environment
1. cd backend
2. npm run dev

// Frontend - Development
1. cd frontend
2. npm run dev

// Frontend - Production
1. cd frontend
2. npm run build
3. npm run start

// Mobile - Run on Web Through Expo
1. cd mobile
2. yarn web
```

In order to run the mobile app through Tunel on your phone, press `Tunel` on the bottom left after running the commands to start the mobile app. Once started, open your camera app and take a screenshot of the QR Code, it will open the app in Expo on your phone.

### Final Notes

We're gonna win and do great things it'll be super fun!

## Authors

* **Akansh Divker** - *Author* - [AkanshDivker](https://github.com/AkanshDivker)
* **Heeyeon Kang** - *Author* - [onhyh](https://github.com/onhyh)

## License

This project is private and not available for distribution.
