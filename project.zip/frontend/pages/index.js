import React, { useState, useEffect } from 'react';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import Header from '../src/Header';
import Footer from '../src/Footer';
import { getGetAssertionChallenge, getMakeCredentialsChallenge, sendWebAuthnResponse, getProfile, logout, registerFail } from '../src/webauthn';
import { preformatGetAssertReq, preformatMakeCredReq, publicKeyCredentialToJSON } from '../src/helpers';
import axios from 'axios';


const useStyles = makeStyles((theme) => ({
    icon: {
        marginRight: theme.spacing(2),
    },
    heroContent: {
        backgroundImage: `url(/home-bg-2.png)`,
        backgroundColor: theme.palette.primary,
        padding: theme.spacing(8, 0, 6),
    },
    heroButtons: {
        marginTop: theme.spacing(4),
    },
    cardGrid: {
        paddingTop: theme.spacing(8),
        paddingBottom: theme.spacing(8),
    },
    card: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
    },
    cardMedia: {
        paddingTop: '56.25%', // 16:9
    },
    cardContent: {
        flexGrow: 1,
    },
    text: {
        color: '#fff',
    },
    container: {
        paddingTop: '5%',
    },
    featureImage: {
        width: '100%',
        height: 300,
    }
}));

export default function Index() {
    const classes = useStyles();

    return (
        <React.Fragment>
            <Header title="Home" />
            <div className={classes.heroContent}>
                <Container maxWidth="sm" className={classes.container}>
                    <Typography className={classes.text} component="h1" variant="h2" align="center" gutterBottom>
                        Some Title
                    </Typography>
                    <Typography className={classes.text} variant="h5" align="center" paragraph>
                        Something short and leading about how cool and secure everything is,
                        or just something cool and catchy to put on the front page.
                    </Typography>
                    <div className={classes.heroButtons}>
                        <Grid container spacing={2} justify="center">
                            <Grid item>
                                <Button variant="contained" color="secondary">
                                    Main call to action
                                </Button>
                            </Grid>
                            <Grid item>
                                <Button variant="outlined" color="secondary">
                                    Secondary action
                                </Button>
                            </Grid>
                        </Grid>
                    </div>
                </Container>
            </div>
            {/* End hero unit */}
            <Container className={classes.cardGrid} maxWidth="lg">
                <Grid container spacing={4}>
                    <Grid item xs={12}>
                        {/* First grid item */}
                        <Typography color="textPrimary" component="h5" variant="h5" align="center" gutterBottom>
                            First Title Thing
                        </Typography>
                        <br />
                        <br />
                        <br />
                        <br />
                        <Grid container spacing={6}>
                            <Grid item xs={6}>
                                <Container className={classes.featureImage} elevation={0} style={{ backgroundImage: `url(/home-bg-1.png)` }} />
                            </Grid>
                            <Grid item xs={6}>
                                <Container className={classes.featureImage} elevation={0}>
                                    <Typography color="textPrimary" component="h6" variant="h6" align="left" gutterBottom>
                                        Test caption for first thing saying how cool it is or what it does.
                                    </Typography>
                                </Container>
                            </Grid>
                        </Grid>
                        {/* Second grid item */}
                        <br />
                        <br />
                        <br />
                        <br />
                        <Typography color="textPrimary" component="h5" variant="h5" align="center" gutterBottom>
                            Second Title Thing
                        </Typography>
                        <br />
                        <br />
                        <br />
                        <br />
                        <Grid container spacing={6}>
                            <Grid item xs={6}>
                                <Container className={classes.featureImage} elevation={0}>
                                    <Typography color="textPrimary" component="h6" variant="h6" align="left" gutterBottom>
                                        Test caption for first thing saying how cool it is or what it does.
                                    </Typography>
                                </Container>
                            </Grid>
                            <Grid item xs={6}>
                                <Container className={classes.featureImage} elevation={0} style={{ backgroundImage: `url(/home-bg-1.png)` }} />
                            </Grid>
                        </Grid>
                        {/* Third grid item */}
                        <br />
                        <br />
                        <br />
                        <br />
                        <Typography color="textPrimary" component="h5" variant="h5" align="center" gutterBottom>
                            Third Title Thing
                        </Typography>
                        <br />
                        <br />
                        <br />
                        <br />
                        <Grid container spacing={6}>
                            <Grid item xs={6}>
                                <Container className={classes.featureImage} elevation={0} style={{ backgroundImage: `url(/home-bg-1.png)` }} />
                            </Grid>
                            <Grid item xs={6}>
                                <Container className={classes.featureImage} elevation={0}>
                                    <Typography color="textPrimary" component="h6" variant="h6" align="left" gutterBottom>
                                        Test caption for first thing saying how cool it is or what it does.
                                    </Typography>
                                </Container>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </Container>
            <Footer />
        </React.Fragment>
    );
}