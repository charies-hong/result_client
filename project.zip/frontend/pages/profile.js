import React, { useState, useEffect } from 'react';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import TextField from '@material-ui/core/TextField';
import Avatar from '@material-ui/core/Avatar';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '../src/Link';
import { getGetAssertionChallenge, sendWebAuthnResponse, getProfile, logout, registerFail } from '../src/webauthn';
import { preformatGetAssertReq, publicKeyCredentialToJSON } from '../src/helpers';
import axios from 'axios';


const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(8),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}));

export default function Profile() {
    const classes = useStyles();

    const [loggedIn, setLoggedIn] = useState(false);
    const [profileData, setProfileData] = useState(null);

    useEffect(() => {
        if (localStorage.getItem('loggedIn')) {
            getProfile()
                .then(data => {
                    setProfileData(data);
                    setLoggedIn(true);
                })
                .catch(err => {
                    alert(err.response.data);
                    localStorage.removeItem('loggedIn');
                });
        }
    }, []);

    const handleLogout = () => {
        logout().then(() => {
            localStorage.removeItem('loggedIn');
            setLoggedIn(false);
            setProfileData(null);
        });
    };

    return (
        <React.Fragment>
            <Container component="main" maxWidth="xs">
                <div className={classes.paper}>
                    <Avatar className={classes.avatar}>
                        <LockOutlinedIcon />
                    </Avatar>
                    <Typography component="h1" variant="h5">
                        Profile
                    </Typography>
                    {!loggedIn ?
                        <Typography className={classes.text} component="h1" variant="h2" align="center" gutterBottom>
                            Not logged in
                        </Typography>
                        :
                        <div>
                            <Typography className={classes.text} component="h1" variant="h2" align="center" gutterBottom>
                                Welcome, {profileData.name}
                            </Typography>
                            <Button
                                fullWidth
                                onClick={() => { handleLogout(); }}
                                variant="contained"
                                color="primary"
                                className={classes.submit}
                            >
                                Logout
                            </Button>
                        </div>
                    }
                </div>
            </Container>
        </React.Fragment>
    );
}