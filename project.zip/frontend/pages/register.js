import React, { useState, useEffect } from 'react';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import TextField from '@material-ui/core/TextField';
import Avatar from '@material-ui/core/Avatar';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '../src/Link';
import { getMakeCredentialsChallenge, sendWebAuthnResponse, registerFail } from '../src/webauthn';
import { preformatMakeCredReq, publicKeyCredentialToJSON } from '../src/helpers';
import axios from 'axios';


const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(8),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}));

export default function Register() {
    const [email, setEmail] = useState('');
    const [name, setName] = useState('');

    const classes = useStyles();

    const handleRegister = () => {
        getMakeCredentialsChallenge({ email, name })
            .then((response) => {
                const publicKey = preformatMakeCredReq(response);
                return navigator.credentials.create({ publicKey });
            })
            .then((response) => {
                const makeCredResponse = publicKeyCredentialToJSON(response);
                return sendWebAuthnResponse(makeCredResponse);
            })
            .then((response) => {
                if (response.status === 'ok') {
                    alert('You can now try logging in');
                }
                else
                    alert(response.message);
            })
            .catch(err => {
                registerFail({ email })
                    .then(() => {
                        if (err.response)
                            setErrMsg(err.response.data);
                        else
                            console.log(err);
                    });
            });
    };

    function handleSubmit(event) {
        event.preventDefault();
        handleRegister();
    }

    return (
        <React.Fragment>
            <Container component="main" maxWidth="xs">
                <div className={classes.paper}>
                    <Avatar className={classes.avatar}>
                        <LockOutlinedIcon />
                    </Avatar>
                    <Typography component="h1" variant="h5">
                        Register
                    </Typography>
                    <form className={classes.form} validate="true" onSubmit={handleSubmit}>
                        <TextField
                            value={name}
                            onInput={e => setName(e.target.value)}
                            variant="outlined"
                            margin="normal"
                            required
                            fullWidth
                            id="name"
                            label="Name"
                            name="name"
                            autoComplete="name"
                            autoFocus
                        />
                        <TextField
                            value={email}
                            onInput={e => setEmail(e.target.value)}
                            variant="outlined"
                            margin="normal"
                            required
                            fullWidth
                            id="email"
                            label="Email Address"
                            name="email"
                            autoComplete="email"
                        />
                        <FormControlLabel
                            control={<Checkbox value="marketing" color="primary" />}
                            label="Receive marketing and other promotional updates via email."
                        />
                        <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            color="primary"
                            className={classes.submit}
                        >
                            Register
                        </Button>
                        <Grid container>
                            <Grid item>
                                <Link href="/login" variant="body2">
                                    {"Already have an account? Login"}
                                </Link>
                            </Grid>
                        </Grid>
                    </form>
                </div>
            </Container>
        </React.Fragment>
    );
}