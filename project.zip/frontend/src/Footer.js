import React from 'react';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';


const useStyles = makeStyles((theme) => ({
    footer: {
        padding: theme.spacing(3, 2),
        marginTop: 'auto',
        backgroundColor:
            theme.palette.type === 'light' ? theme.palette.grey[200] : theme.palette.grey[800],
    },
}));

function Copyright() {
    return (
        <Typography variant="body2" color="textSecondary">
            Copyright &#169;
            {' '}
            <Link color="inherit" href="https://material-ui.com/">
                {'CuteHorse'}
            </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

export default function Footer() {
    const classes = useStyles();

    return (
        <footer className={classes.footer}>
            <Container maxWidth="sm">
                <Grid container spacing={2} justify="center">
                    <Typography variant="body1">Put some footer links or something here</Typography>
                </Grid>
                <br />
                <Grid container spacing={2} justify="center">
                    <Copyright />
                </Grid>
            </Container>
        </footer>
    );
}