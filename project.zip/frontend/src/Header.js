import React from 'react';
import PropTypes from 'prop-types';
import Head from 'next/head';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import useScrollTrigger from '@material-ui/core/useScrollTrigger';


const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    title: {
        flexGrow: 1,
    },
}));

function ElevationScroll(props) {
    const { children } = props;

    const trigger = useScrollTrigger({
        disableHysteresis: true,
        threshold: 50,
    });

    return React.cloneElement(children, {
        elevation: trigger ? 4 : 0,
        style: trigger ? { 'backgroundColor': 'rgba(106, 27, 154, 1)' } : { 'backgroundColor': 'rgba(106, 27, 154, 0)' },
    });
}

ElevationScroll.propTypes = {
    children: PropTypes.element.isRequired,
};

export default function Header(props) {
    const classes = useStyles();

    return (
        <React.Fragment>
            <Head>
                <title>CuteHorse - {props.title}</title>
                <meta name="viewport" content="minimum-scale=1, initial-scale=1, width=device-width" />
            </Head>
            <div className={classes.root}>
                <ElevationScroll {...props}>
                    <AppBar position="fixed">
                        <Toolbar>
                            <Typography variant="h6" className={classes.title}>
                                CuteHorse
                        </Typography>
                            <Button color="inherit" href="/">Home</Button>
                            <Button color="inherit" href="/about">About</Button>
                            <Button color="inherit" href="/contact">Contact</Button>
                            <Button color="inherit" href="/profile">Profile</Button>
                            <Button variant="contained" color="secondary" href="/login">Login</Button>
                        </Toolbar>
                    </AppBar>
                </ElevationScroll>
            </div>
        </React.Fragment>
    );
}